<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class indexHomeController extends Controller
{
    //
    public function index()
    {
    	# code...
    	return view('indexhome');
    }


    public function FunctionName($value='')
    {
    	# code...
    }
}
