<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class statetnispend extends Model
{
    //
    protected $fillable = ['etnis', 'pria', 'wanita', 'jumlah' ,'created_at', 'updated_at'];
}
