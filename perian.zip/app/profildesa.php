<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class profildesa extends Model
{
    //
    protected $fillable = ['desripsiprofildesa', 'fotokades' ,'fotoketbpd', 'fotosekdes', 'fotokaurpemerintahan', 'fotokaurpembangunan', 'fotokaurkeuangan', 'fotokaurumum', 'fotokaurkesra', 'fotokaurtrantib','created_at', 'updated_at'];
}
