<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class jmlpend extends Model
{
    //
    protected $fillable = ['wilayah', 'jumlah' ,'created_at', 'updated_at'];
}
