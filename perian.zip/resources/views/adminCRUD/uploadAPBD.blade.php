@extends('layouts.layoutform')

@section('content')
<form action={{ url('uploadapbd/' .  $id ) }} method="post" enctype="multipart/form-data" style="padding-top: 100px;">
          {{ csrf_field() }}
          Tahun :<br>
          <input type="text" name="tahunapbd" value="2018"><br><br>
          Upload file : <br><br>
          <input type="file" name="url_gambar[]" multiple>
          <br><br>
          <input type="submit" value="Submit">
        </form>
@if ($errors->any())
        <h3 class="text-center text-danger">{{ implode('', $errors->all(':message')) }}</h3>
        @endif
@endsection



    
        
